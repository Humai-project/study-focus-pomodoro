/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studyfocus;

/**
 *
 * @author humai
 */
public class Tugas {
    private final int id;
    private final String judul;
    private final String matkul;
    private final String deadline;   

    public Tugas(int id, String judul, String matkul, String deadline) {
        this.id = id;
        this.judul = judul;
        this.matkul = matkul;
        this.deadline = deadline;
    }

    public int getId() { return id; }
    public String getJudul() { return judul; }
    public String getMatkul() { return matkul; }
    public String getDeadline() { return deadline; }
}

