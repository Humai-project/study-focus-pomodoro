/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studyfocus;

/**
 *
 * @author humai
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class TugasDAO {

    private final Connection conn;

    public TugasDAO(Connection conn) {
        this.conn = conn;
    }

    
public List<Tugas> getAllTugas() {
    List<Tugas> list = new ArrayList<>();
    String sql = "SELECT id, judul, matkul, deadline FROM tugas ORDER BY id DESC";

    try (PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            int id = rs.getInt("id");
            String judul = rs.getString("judul");
            String matkul = rs.getString("matkul");
            String deadline = rs.getString("deadline"); // kalau kolomnya DATE, boleh pakai rs.getString juga

            list.add(new Tugas(id, judul, matkul, deadline));
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null,
                "Gagal mengambil tugas: " + e.getMessage());
    }
    return list;
}


    // simpan tugas baru
public void insertTugas(String judul, String matkul, String deadline) {
    String sql = "INSERT INTO tugas (judul, matkul, deadline, tipe) VALUES (?, ?, ?, 'TUGAS')";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, judul);
        ps.setString(2, matkul);
        ps.setString(3, deadline);   // misal "2025-12-31"
        ps.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null,
                "Gagal menyimpan tugas: " + e.getMessage());
    }
}


    // hapus tugas berdasarkan judul
    public void deleteByJudul(String judul) {
        String sql = "DELETE FROM tugas WHERE judul = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, judul);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                    "Gagal menghapus tugas: " + e.getMessage());
        }
    }
}
