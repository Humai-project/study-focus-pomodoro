/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studyfocus;

/**
 *
 * @author humai
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class StudyFocusFrame extends JFrame {

    // UI
    private JLabel lblTimer, lblMode, lblCurrentTask;
    private JButton btnStart, btnPause, btnReset;
    private JButton btnAddTask, btnDeleteTask;
    private JTable taskTable;
    private DefaultTableModel taskTableModel;
    private JComboBox<String> cmbMode;   // pilih mode manual (optional)

    // Timer
    private Timer timer;
    private int remainingSeconds;
    private boolean running = false;

    private Integer customMinutes = null;
    
    // Pomodoro config
    private static final int FOCUS_SECONDS = 25 * 60;
    private static final int SHORT_BREAK_SECONDS = 5 * 60;
    private static final int LONG_BREAK_SECONDS = 10 * 60;
    private int pomodoroCount = 0;   // jumlah focus yang sudah selesai

    // Mode
    private enum Mode { FOCUS, SHORT_BREAK, LONG_BREAK }
    private Mode currentMode = Mode.FOCUS;

    // DB
    private Connection conn;
    private TugasDAO tugasDAO;

    public StudyFocusFrame(Connection conn) {
        this.conn = conn;
        this.tugasDAO = new TugasDAO(conn);

        initUI();
        initTimer();
        switchMode(Mode.FOCUS);  // set awal 25 menit
        loadTasksFromDb();

        setTitle("Study Focus - Pomodoro Timer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 520);
        setLocationRelativeTo(null);
    }

    // ================= UI =================

    private void initUI() {
        // Panel kiri: timer
        JPanel leftPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 192, 203));
                getContentPane().setBackground(new Color(255, 228, 235)); 
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                g2.dispose();
            }
        };
        leftPanel.setOpaque(false);
        leftPanel.setLayout(new BorderLayout(10, 10));
        leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        lblMode = new JLabel("FOCUS", SwingConstants.CENTER);
        lblMode.setFont(new Font("Segoe UI", Font.BOLD, 18));

        lblTimer = new JLabel("25:00", SwingConstants.CENTER);
        lblTimer.setFont(new Font("Segoe UI", Font.BOLD, 56));
     
        lblCurrentTask = new JLabel("No task selected", SwingConstants.CENTER);
        lblCurrentTask.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        lblMode.setForeground(new Color(80, 30, 60));
        lblTimer.setForeground(new Color(80, 30, 60));
        lblCurrentTask.setForeground(new Color(80, 30, 60));

        JPanel topTimerPanel = new JPanel(new GridLayout(3, 1, 0, 5));
        topTimerPanel.setOpaque(false);
        topTimerPanel.add(lblMode);
        topTimerPanel.add(lblTimer);
        topTimerPanel.add(lblCurrentTask);

        JPanel controlPanel = new JPanel();
        controlPanel.setOpaque(false);
        btnStart = new JButton("Start");
        btnPause = new JButton("Pause");
        btnReset = new JButton("Reset");

        stylePrimaryButton(btnStart);
        styleSecondaryButton(btnPause);
        styleSecondaryButton(btnReset);

        controlPanel.add(btnStart);
        controlPanel.add(btnPause);
        controlPanel.add(btnReset);

        // Combo mode manual
        cmbMode = new JComboBox<>(new String[]{
            "Focus 25", "Short Break 5", "Long Break 10", "Custom..."
        });

        JPanel bottomLeft = new JPanel(new BorderLayout());
        bottomLeft.setOpaque(false);
        bottomLeft.add(controlPanel, BorderLayout.CENTER);
        bottomLeft.add(cmbMode, BorderLayout.SOUTH);

        leftPanel.add(topTimerPanel, BorderLayout.CENTER);
        leftPanel.add(bottomLeft, BorderLayout.SOUTH);

        // Panel kanan: task list
        String[] cols = {"Judul", "MataKuliah", "Deadline"};
        taskTableModel = new DefaultTableModel(cols, 0);
        taskTable = new JTable(taskTableModel);
        taskTable.setRowHeight(28);

        JScrollPane scroll = new JScrollPane(taskTable);

        JPanel taskButtons = new JPanel();
        btnAddTask = new JButton("Add Task");
        btnDeleteTask = new JButton("Delete Task");
        styleSecondaryButton(btnAddTask);
        styleSecondaryButton(btnDeleteTask);
        taskButtons.add(btnAddTask);
        taskButtons.add(btnDeleteTask);
        Color blueSoft = new Color(129, 140, 248);   // ungu-biru pastel
        btnAddTask.setBackground(blueSoft);
        btnDeleteTask.setBackground(blueSoft);
        btnAddTask.setForeground(Color.WHITE);
        btnDeleteTask.setForeground(Color.WHITE);


        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        rightPanel.add(scroll, BorderLayout.CENTER);
        rightPanel.add(taskButtons, BorderLayout.SOUTH);
        // warna biru soft area tugas
        Color blueBg = new Color(224, 242, 255);
        Color blueText = new Color(30, 64, 175);

        rightPanel.setBackground(blueBg);
        scroll.getViewport().setBackground(blueBg);
        taskTable.setBackground(blueBg);
        taskTable.setForeground(blueText);

        taskTable.getTableHeader().setBackground(new Color(191, 219, 254));
        taskTable.getTableHeader().setForeground(blueText);

        // Split pane
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        split.setDividerLocation(380);
        split.setBorder(null);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(split, BorderLayout.CENTER);
        getContentPane().setBackground(new Color(18, 18, 25));

        // Listeners
        btnStart.addActionListener(this::onStart);
        btnPause.addActionListener(e -> pauseTimer());
        btnReset.addActionListener(e -> resetCurrentMode());
        btnAddTask.addActionListener(e -> addTaskDialog());
        btnDeleteTask.addActionListener(e -> deleteSelectedTask());


cmbMode.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        if (!running) {
            String sel = (String) cmbMode.getSelectedItem();
            if (sel.startsWith("Focus")) {
                switchMode(Mode.FOCUS);
            } else if (sel.startsWith("Short")) {
                switchMode(Mode.SHORT_BREAK);
            } else if (sel.startsWith("Long")) {
                switchMode(Mode.LONG_BREAK);
            } else {
                // ===== Custom HH:MM:SS =====
                JTextField txtJam = new JTextField();
                JTextField txtMenit = new JTextField();
                JTextField txtDetik = new JTextField();

                JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
                panel.add(new JLabel("Jam (HH):"));
                panel.add(txtJam);
                panel.add(new JLabel("Menit (MM):"));
                panel.add(txtMenit);
                panel.add(new JLabel("Detik (SS):"));
                panel.add(txtDetik);

                int result = JOptionPane.showConfirmDialog(
                        StudyFocusFrame.this,
                        panel,
                        "Custom Timer (HH:MM:SS)",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.PLAIN_MESSAGE
                );

                if (result == JOptionPane.OK_OPTION) {
                    String hStr = txtJam.getText().trim();
                    String mStr = txtMenit.getText().trim();
                    String sStr = txtDetik.getText().trim();

                    if (hStr.isEmpty()) hStr = "0";
                    if (mStr.isEmpty()) mStr = "0";
                    if (sStr.isEmpty()) sStr = "0";

                    try {
                        int h = Integer.parseInt(hStr);
                        int m = Integer.parseInt(mStr);
                        int s = Integer.parseInt(sStr);

                        if (h < 0 || m < 0 || s < 0) {
                        JOptionPane.showMessageDialog(
                                StudyFocusFrame.this,
                                "Jam, menit, dan detik tidak boleh negatif."
                        );
                        return;
                    }

                       int totalSec = h * 3600 + m * 60 + s;
                        if (totalSec <= 0) {
                            JOptionPane.showMessageDialog(
                                    StudyFocusFrame.this,
                                    "Durasi harus lebih dari 0 detik."
                            );
                            return;
                        }

                        customMinutes = totalSec / 60;   // opsional
                        currentMode = null;              // mode custom
                        remainingSeconds = totalSec;
                        lblMode.setText("CUSTOM");
                        lblTimer.setText(formatTime(remainingSeconds));

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(
                                StudyFocusFrame.this,
                                "Jam, menit, dan detik harus berupa angka."
                        );
                    }
                }
            }
        }
    }
});

  
        taskTable.getSelectionModel().addListSelectionListener(e -> updateCurrentTaskLabel());
    }

private void stylePrimaryButton(JButton b) {
    b.setBackground(new Color(255, 105, 180)); 
    b.setForeground(Color.WHITE);
    b.setFocusPainted(false);
    b.setBorderPainted(false);
}

private void styleSecondaryButton(JButton b) {
    b.setBackground(new Color(129, 140, 248));    
    b.setForeground(Color.WHITE);
    b.setFocusPainted(false);
    b.setBorderPainted(false);
}


    // ================= TIMER & MODE =================

    private void initTimer() {
        timer = new Timer(1000, e -> {
            if (remainingSeconds > 0) {
                remainingSeconds--;
                lblTimer.setText(formatTime(remainingSeconds));
            } else {
                timer.stop();
                running = false;
                handleSessionFinished();
            }
        });
    }

    private void onStart(ActionEvent e) {
        if (!running) {
            running = true;
            timer.start();
        }
    }

    private void pauseTimer() {
        if (running) {
            running = false;
            timer.stop();
        }
    }

    private void resetCurrentMode() {
    running = false;
    timer.stop();
    if (currentMode == null && customMinutes != null) { // mode custom
        remainingSeconds = customMinutes * 60;
    } else {
        setTimeForMode(currentMode);
    }
    lblTimer.setText(formatTime(remainingSeconds));
}


    private void switchMode(Mode mode) {
        currentMode = mode;
        setTimeForMode(mode);
        lblTimer.setText(formatTime(remainingSeconds));

        switch (mode) {
            case FOCUS:
                lblMode.setText("FOCUS");
                cmbMode.setSelectedIndex(0);
                break;
            case SHORT_BREAK:
                lblMode.setText("SHORT BREAK");
                cmbMode.setSelectedIndex(1);
                break;
            case LONG_BREAK:
                lblMode.setText("LONG BREAK");
                cmbMode.setSelectedIndex(2);
                break;
        }
    }

    private void setTimeForMode(Mode mode) {
        if (mode == Mode.FOCUS) remainingSeconds = FOCUS_SECONDS;
        else if (mode == Mode.SHORT_BREAK) remainingSeconds = SHORT_BREAK_SECONDS;
        else remainingSeconds = LONG_BREAK_SECONDS;
    }

    private void handleSessionFinished() {
         if (currentMode == null) { // custom timer
        JOptionPane.showMessageDialog(this,
                "Custom timer selesai.");
        return; // tidak auto pindah ke break/focus
    }

        if (currentMode == Mode.FOCUS) {
            pomodoroCount++;
            if (pomodoroCount % 4 == 0) {
                switchMode(Mode.LONG_BREAK);
                JOptionPane.showMessageDialog(this,
                        "Focus selesai! Waktunya long break 10 menit.");
            } else {
                switchMode(Mode.SHORT_BREAK);
                JOptionPane.showMessageDialog(this,
                        "Focus selesai! Short break 5 menit.");
            }
        } else {
            switchMode(Mode.FOCUS);
            JOptionPane.showMessageDialog(this,
                    "Break selesai! Siap fokus lagi 25 menit.");
        }
    }

  private String formatTime(int totalSeconds) {
    int h = totalSeconds / 3600;
    int m = (totalSeconds % 3600) / 60;
    int s = totalSeconds % 60;
    if (h > 0) {
        return String.format("%02d:%02d:%02d", h, m, s);
    } else {
        return String.format("%02d:%02d", m, s);
    }
}


    // ================= TASK & DB =================

private void loadTasksFromDb() {
    taskTableModel.setRowCount(0);
    for (Tugas t : tugasDAO.getAllTugas()) {
        taskTableModel.addRow(new Object[]{
            t.getJudul(),
            t.getMatkul(),
            t.getDeadline()
        });
    }
}


private void addTaskDialog() {
    JTextField txtJudul = new JTextField();
    JTextField txtMatkul = new JTextField();
    JTextField txtDeadline = new JTextField(); // contoh: 2025-12-31

    JPanel panel = new JPanel(new GridLayout(0, 1));
    panel.add(new JLabel("Judul tugas:"));
    panel.add(txtJudul);
    panel.add(new JLabel("Mata kuliah:"));
    panel.add(txtMatkul);
    panel.add(new JLabel("Deadline (YYYY-MM-DD):"));
    panel.add(txtDeadline);

    int result = JOptionPane.showConfirmDialog(this, panel,
            "Add Task", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
        String judul = txtJudul.getText().trim();
        String matkul = txtMatkul.getText().trim();
        String deadline = txtDeadline.getText().trim();

        if (!judul.isEmpty()) {
            tugasDAO.insertTugas(judul, matkul, deadline);
            loadTasksFromDb();
        } else {
            JOptionPane.showMessageDialog(this, "Judul tidak boleh kosong.");
        }
    }
}


    private void deleteSelectedTask() {
        int row = taskTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a task first.");
            return;
        }
        String judul = (String) taskTableModel.getValueAt(row, 0);
        tugasDAO.deleteByJudul(judul);
        loadTasksFromDb();
    }

    private void updateCurrentTaskLabel() {
        int row = taskTable.getSelectedRow();
        if (row == -1) {
            lblCurrentTask.setText("No task selected");
        } else {
            String judul = (String) taskTableModel.getValueAt(row, 0);
            lblCurrentTask.setText(judul);
        }
    }
}

